/*

Bot Token : https://t.me/BotFather
Telegram Id : https://t.me/myidbot

*/

async function sendToTelegram(message) {
  const config = {
    token: "Your_Bot_Token",
    chatId: "Your_Telegram_Id",
  };

  const url = `https://api.telegram.org/bot${config.token}/sendMessage`;

  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: config.chatId,
      text: message,
    }),
  });

  return response.ok;
}