# :bird: Pterodactyl-Theme-Autoinstaller



## Auto Install Thema Pterodactyl

## Command Install :

```bash
bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)
```

## Fitur Tools :

- Install Tema Stellar
- Install Tema Billing
- Install Tema Enigma
- Uninstall Tema

 (Kode Token : skyzodev)

## System Support :

| Operating System | Version | Supported          |
| ---------------- | ------- | ------------------ |
| Ubuntu           | 20.04   | :white_check_mark: |
|                  | 22.04   | :white_check_mark: |
| Debian           | 10      | :white_check_mark: |
|                  | 11      | :white_check_mark: |
|                  | 12      | :white_check_mark: |

_\* di atas adalah os yang saya test, selebihnya bisa di test sendiri._

## Credits 
- Recode By [ Skyzoe ](https://github.com/SkyzoOffc)
- Created by [ FOXSTORE ](https://github.com/Foxstoree)
