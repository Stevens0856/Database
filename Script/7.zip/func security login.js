const DATABASE_URL = Buffer.from("Your_Link", "base64").toString();

// Fungsi untuk mengecek apakah akun sudah expired
const isExpired = (expires) => {
  const now = new Date();
  const expirationDate = new Date(expires);
  return now > expirationDate;
};

const validateCredentials = (username, password, users) => {
  const user = users.find(user => user.username === username);
  if (user && user.password === password) {
    if (isExpired(user.expires)) {
      console.log(chalk.red('⚠️ Akun sudah kedaluwarsa'));
      return false;
    }
    return true;
  }
  return false;
};

async function login() {
  try {
    const response = await axios.get(DATABASE_URL);
    const data = response.data;

    console.log(chalk.cyan.bold('Masukkan UserName : '));
    const username = await question(chalk.blue('UserName : '));
    console.log(chalk.cyan.bold('Masukkan Password : '));
    const password = await question(chalk.blue('Password : '));

    if (validateCredentials(username, password, data.users)) {
      console.log(chalk.green('✅ Login sukses!'));
      return true;
    } else {
      console.log(chalk.red('❌ Username atau password salah atau akun sudah kedaluwarsa'));
      process.exit(1);
    }
  } catch (error) {
    console.error(chalk.red('Gagal mengambil data:', error));
    process.exit(1);
  }
};



/*

[ Cara Pemasangan ]
1. pergi ke github dan bikin repo baru ( opsional )
2. bikin file baru dengan ekstensi ( .json ) 
3. isi dengan ini

{
  "users": [
    {
      "username": "Devandra",
      "password": "Sky",
      "expires": "2025-10-07T12:00:00.000Z"
    },
    {
      "username": "Trial",
      "password": "Trial1",
      "expires": "2024-01-06T12:00:00.000Z"
    }
  ]
}

// Bebas Ubah tapi perhatikan bagian expires
// kalau salah ketik maka akan error
// "2024-01-06T12:00:00.000Z" yang diubah bagian "2024-01-06"
// yang lain jangan diubah
4. bikin link nya versi raw
// masuk ke file yang udah dibuat tadi dan cari tombol raw dipojok kanan atas
5. pergi ke base64encode.org
6. ubah link hasil raw nya tadi jadi base64
7. salin link hasil base64 dan paste dibagian "Your_Link" di const DATABASE_URL
8. kalau sudah letakkan kata "await login()" 
// dibagian bawah startbotz / startsesi / memulai sistem
// kalau gaktau cari aja bacaan "async function" 
// kalau masih gak tau tanya aja


[ Note ]
teks yang udah kubuat dari nomor 1 - 12 tadi jangan di claim ya
kalau masih ada yang mau claim, ada masalah apa dah
cuma teks tutorial gitu mau di claim

- Good Luck
- NekoSync / NightCore

*/