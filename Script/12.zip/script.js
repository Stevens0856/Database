document.addEventListener('DOMContentLoaded', () => {
  const urlParams = new URLSearchParams(window.location.search);
  const productId = urlParams.get('id');

  fetch('database.json')
    .then(response => response.json())
    .then(data => {
      const product = data.products.find(p => p.id == productId);
      if (product) {
        const productDetail = document.getElementById('product-detail');
        productDetail.innerHTML = `
                    <div class="col-md-6 mb-4">
                        <img src="${product.image}" class="img-fluid" alt="${product.name}">
                    </div>
                    <div class="col-md-6 mb-4">
                        <h1>${product.name}</h1>
                        <p>${product.description}</p>
                        <p><strong>$${product.price}</strong></p>
                        <a href="order.html" class="btn btn-primary">Order Product</a>
                    </div>
                `;
      } else {
        document.getElementById('product-detail').innerHTML = '<p>Product not found.</p>';
      }
    });
});