/*
• Base Ori GhostXmods X WannOFFC
Penting ‼️

Hapus Bagian/Teks Ini? Masuk Neraka Paling Bawah

Script Ini Murni Bikinan Sendiri, Saya Hanya Sekedar Kroco Penghuni Inti Bumi.

Thanks To :                                
- Allah Swt 
- Nabi Muhammad Saw         
- My Parents       
- WannOFFICIAL [ Develover Sc ]  
- GhostXmods [ Support ]
- Pengguna Bot Yang Selalu Support

• Recode By ( Nama Mu )
*/

const config = {
  token: 'TOKEN_BOT_FATHER',
  adminId: 'ID_TELE',
  pp: 'https://telegra.ph/file/8ef2d072f8c68f120d18d.jpg',
  ppp: 'https://telegra.ph/file/8ef2d072f8c68f120d18d.jpg',
};

module.exports = config;