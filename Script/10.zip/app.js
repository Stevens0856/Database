/*
• Base Ori GhostXmods X WannOFFC
Penting ‼️

Hapus Bagian/Teks Ini? Masuk Neraka Paling Bawah

Script Ini Murni Bikinan Sendiri, Saya Hanya Sekedar Kroco Penghuni Inti Bumi.

Thanks To :                                
- Allah Swt 
- Nabi Muhammad Saw         
- My Parents       
- WannOFFICIAL [ Develover Sc ]  
- GhostXmods [ Support ]
- Pengguna Bot Yang Selalu Support

• Recode By ( Nama Mu )
*/

const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const axios = require('axios');

const settings = require('./config'); 
const Token = settings.token;
const owner = settings.adminId;
const premiumUsersFile = 'db/premiumUsers.json';
try {
    premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
} catch (error) {
    console.error('Error reading premiumUsers file:', error);
}
const bot = new TelegramBot(Token, { polling: true });

const zones = {
    'zone': 'domain',
    'zone': 'domain',
    'zone': 'domain',
    'zone': 'domain',
    'zone': 'domain',   
    'zone': 'domain',
    'zone': 'domain',
    'zone': 'domain',
    'zone': 'domain',
    'zone': 'domain'
};

const apiTokens = {
    'zone ': 'apitokenCloudflare',
    'zone ': 'apitokenCloudflare',
    'zone ': 'apitokenCloudflare',
    'zone ': 'apitokenCloudflare',
    'zone ': 'apitokenCloudflare',
    'zone ': 'apitokenCloudflare',
    'zone ': 'apitokenCloudflare',
    'zone ': 'apitokenCloudflare',
    'zone ': 'apitokenCloudflare',
    'zone ': 'apitokenCloudflare'
    
// setelah isi ini, isi juga zone&token di perintah 1-10 yaa cari aja
};

function getRuntime(startTime) {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    return `${hours} Jam ${minutes} Menit ${seconds} Detik`;
}
// Informasi waktu mulai bot
const startTime = Date.now();
const nama = "wannpyyy"
const author = "© 𝙒𝙖𝙣𝙣𝙊𝙁𝙁𝘾 χ 𝙂𝙝𝙤𝙨𝙩𝙓𝙈𝙤𝙙𝙨"
bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const startTime = Date.now();
    const menuText = `
┏━━ 𝗜𝗡𝗙𝗢 𝗠𝗘𝗡𝗨 ━⊜

 ∘ 🤖 Nama Bot: ${nama}
 ∘ 👤 Author Bot: ${author}
 ∘ ⏲️ Runtime: ${getRuntime(startTime)}

┗━━━━━━━━━━━━━━

┏━━ 𝗟𝗜𝗦𝗧 𝗠𝗘𝗡𝗨 ━⊜
 ∘ /addprem
 ∘ /delprem 
 ∘ /cekid
 ∘ /donasi
 © 𝙒𝙖𝙣𝙣𝙊𝙁𝙁𝘾 χ 𝙂𝙝𝙤𝙨𝙩𝙓𝙈𝙤𝙙𝙨
┗━━━━━━━━━━━━━━━━`;

// Event listener for button 'Start'
bot.on('callback_query', (callbackQuery) => {
    if (callbackQuery.data === 'start') {
        const chatId = callbackQuery.message.chat.id;
        const startTime = Date.now();

        const menuText = `
┏━━ 𝗜𝗡𝗙𝗢 𝗠𝗘𝗡𝗨 ━⊜

 ∘ 🤖 Nama Bot: ${nama}
 ∘ 👤 Author Bot: ${author}
 ∘ ⏲️ Runtime: ${getRuntime(startTime)}

┗━━━━━━━━━━━━━━

┏━━ 𝗟𝗜𝗦𝗧 𝗠𝗘𝗡𝗨 ━⊜
 ∘ /addprem
 ∘ /delprem 
 ∘ /cekid
 ∘ /donasi
 © 𝙒𝙖𝙣𝙣𝙊𝙁𝙁𝘾 χ 𝙂𝙝𝙤𝙨𝙩𝙓𝙈𝙤𝙙𝙨
┗━━━━━━━━━━━━━━━━`;
 const message = menuText;
 const keyboard = {
            reply_markup: {
                inline_keyboard: [
                   [{ text: '🛒 BELI SC BOT 🛒', url: 'https://t.me/WannOFFC08' }],
                    [{ text: '📓 SUBDOLIST', callback_data: 'SUBDOLIST' }, { text: 'DONASI 🏧', url: 'https://telegra.ph/file/e24baed2df0ed8e7967fe.jpg' }],

                ]
            }
        };
        bot.answerCallbackQuery(callbackQuery.id);
        bot.editMessageText(message, {
            chat_id: chatId,
            message_id: callbackQuery.message.message_id,
            reply_markup: keyboard,
            parse_mode: 'Markdown'
        });
    }
});



const message = menuText;
const keyboard = {
  reply_markup: {
  inline_keyboard: [
   [{ text: '🛒 BELI SC BOT 🛒', url: 'https://t.me/WannOFFC08' }],
      
  [{ text: '📓 SUBDOLIST', callback_data: 'SUBDOLIST' }, { text: 'DONASI 🏧', url: 'https://telegra.ph/file/e24baed2df0ed8e7967fe.jpg' }],

            ]
        }
    }; 
    bot.sendMessage(chatId, message, keyboard);
});

bot.on('callback_query', (callbackQuery) => {
  if (callbackQuery.data === 'SUBDOLIST') {
    bot.answerCallbackQuery(callbackQuery.id);
    const ramListMessage = "┏━━ 𝐈𝐍𝐅𝐎 𝐌𝐄𝐍𝐔 ━⊜\n ∘ 𝘓𝘢𝘺𝘢𝘯𝘢𝘯 𝘊𝘋𝘕 : 𝘊𝘓𝘖𝘜𝘋𝘍𝘓𝘈𝘙𝘌\n ∘ 𝘛𝘰𝘵𝘢𝘭 𝘋𝘰𝘮𝘢𝘪𝘯 : 40\n ∘ 𝘛𝘰𝘵𝘢𝘭 𝘋𝘰𝘮𝘢𝘪𝘯 Aktif : 40\n┗━━━━━━━━━━━━━━\n ∘ DISARANKAN UNTUK PTERODACLTY 🚨\n┗━━━━━━━━━━━━━━━━━\n\n∘ /1 kedai-panel.my.id ✅\n∘ /2 mypanell.biz.id ✅\n∘ /3 cpanel-vip.my.id ✅\n∘ /4 prv-panelwann.my.id ✅\n∘ /5 roomdigital.site ✅\n∘ /6 panelprivv.xyz ✅\n∘ /7 tokopanellku.my.id ✅\n∘ /8 kiospanell.my.id ✅\n∘ /9 fastnet.biz.id ✅\n∘ /10 tokopanellmurah.my.id ✅\n∘ /11 bisnispanel.my.id ✅\n∘ /12 xmartpanel.my.id ✅\n∘ /13 tokopanel.biz.id ✅\n∘ /14 store-panel.biz.id ✅\n∘ /15 sellerpanel.biz.id ✅\n∘ /16 panellprivate.my.id ✅\n∘ /17 mypanel.my.id ✅\n∘ /18 kangpanel.biz.id ✅\n∘ /19 jasapanel.my.id ✅\n∘ /20 dewapanel.my.id ✅\n∘ /21 adminpanel.biz.id ✅\n∘ /22 plerkuda.my.id ✅\n∘ /23 cafegt.my.id ✅\n∘ /24 storemurah.my.id ✅\n∘ /25 fastpanel.biz.id ✅\n∘ /26 fastweb.my.id ✅\n∘ /27 jasapanell.my.id ✅\n∘ /28 srvelite.biz.id ✅\n∘ /29 wnn.my.id ✅\n∘ /30 paneellkuu.my.id ✅\n∘ /31 worknet.biz.id ✅\n∘ /32 piwzstoreee.my.id ✅\n∘ /33 piwzpediaaa.biz.id ✅\n∘ /34 piwzpanel.me ✅\n∘ /35 r0ulxye4.my.id ✅\n∘ /36 lanzpanel.my.id ✅\n∘ /37 moon-offc.my.id ✅\n∘ /38 moon-offc.biz.id ✅\n∘ /39 kedaihosting.biz.id ✅\n∘ /40 kioshost.biz.id ✅\n∘ /41 kiospanel.my.id ✅\n∘ /42 myseller.biz.id ✅▬▭▬▭▬▭▬▭▬▭▬▭▬\n NOTE: \n - DILARANG UNTUK DI PAKAI UNTUK WHM/CPANEL\n - DILARANG DDOS SESAMA RESSELER\n - CARA BUAT KETIK CONTOH : /NO SUBDO IP\nCONTOH : /1 wann 62.283.272xxx";
    bot.editMessageText(ramListMessage, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      reply_markup: {
        inline_keyboard: [
          [{ text: 'Kembali ke Menu Start', callback_data: 'start' }]
        ]
      }
    });
  }
});

bot.onText(/\/donasi/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username;
    const owner = '1344553362'; // Ganti dengan ID pemilik bot 
    const text12 = `Hi @${sender} 👋

Jika Ingin Donasi Silahkan Scan Qris Di Atas 😁✌️
Owner @WannOFFC08`;
    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: '🖥️ Buy Panel', url: 'https://t.me/WannOFFC08/buy_panel' }, { text: '👤 Buy Admin', url: 'https://t.me/WannOFFC08/buyadminp & ptpanel' }],
                [{ text: '🇲🇨 Buy Vps', url: 'https://t.me/WannOFFC08/buyvps' }]
            ]
        }
    }
bot.sendPhoto(chatId, 'https://telegra.ph/file/e24baed2df0ed8e7967fe.jpg', { caption: text12, parse_mode: 'Markdown', reply_markup: keyboard });
});

bot.onText(/\/cekid/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username;
    const owner = '1344553362'; // Ganti dengan ID pemilik bot 
    const text12 = `Hi @${sender} 👋
    
👤 From ${msg.from.id}
  └🙋🏽 kamu
  
 ID Telegram Anda: ${msg.from.id}
 Full Name Anda :@${sender}

🙏🏼 Permisi, bot akan pergi secara otomatis.
 Developer : @WannOFFC08`;
    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: '🖥️ Buy Panel', url: 'https://t.me/WannOFFC08/buy_panel' }, { text: '👤 Buy Admin', url: 'https://t.me/WannOFFC08/buyadminp & ptpanel' }],
                [{ text: '🇲🇨 Buy Vps', url: 'https://t.me/WannOFFC08/buyvps' }]
            ]
        }
    };
    bot.sendPhoto(chatId, settings.pp, { caption: text12, parse_mode: 'Markdown', reply_markup: keyboard });
});

bot.onText(/\/addprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        if (!premiumUsers.includes(userId)) {
            premiumUsers.push(userId);
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
            bot.sendMessage(chatId, `User ${userId} has been added to premium users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is already a premium user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});

bot.onText(/\/delprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];  
    if (msg.from.id.toString() === owner) {
        const index = premiumUsers.indexOf(userId);
        if (index !== -1) {
            premiumUsers.splice(index, 1);
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
            bot.sendMessage(chatId, `User ${userId} has been removed from premium users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is not a premium user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});

bot.onText(/\/1 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, 'zone', 'tokenCloudflare');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});

bot.onText(/\/2 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, 'zone', 'tokenCloudflare');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});

bot.onText(/\/3 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, 'zone', 'tokenCloudflare2');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});

bot.onText(/\/4 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, 'zone', 'tokenCloudflare');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});

bot.onText(/\/5 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    
    const response = await createSubdomain(subdomain, ip, 'zone', 'tokenCloudflare');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});

bot.onText(/\/6 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, 'zone', 'tokenCloudflare');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});

bot.onText(/\/7 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, 'zone', 'tokenCloudflare');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});

bot.onText(/\/8 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, 'zone', 'tokenCloudflare');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});

bot.onText(/\/9 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, 'zone', 'tokenCloudflare');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});

bot.onText(/\/10 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, 'zone', 'tokenCloudflare');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});

const createSubdomain = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 3600,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};