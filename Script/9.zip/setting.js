const chalk = require("chalk")
const fs = require("fs")

const payment = {
    qris: {
      link_nya: "https://telegra.ph/file/",
      atas_nama: "bokrp"
    },
    dana: {
      nomer: "08xxxxx",
      atas_nama: "bokep"
    },
    ovo: {
      nomer: "08xxxxx", //Ovo Nonaktif 
      atas_nama: "bokep" 
    }
}

const apikeyAtlantic = "your apikey"
//AKUN H2H 
//https://atlantich2h.com (DISINI KALIAN BISA BUAT PROVIDER NYA)

//BUAT AKUN DISINI DULU
//https://m.atlantic-pedia.co.id/

  global.ownerNumber = "628@s.whatsapp.net"
  global.kontakOwner = "628"
  global.untung = "3"
  //Ini profit yg kamu dapat, 1 = 1% maka harga akan meningkat 1%
  //Isi sesuai kebutuhan 
  global.namaStore = "TAMZHOST"
  global.botName = "TAMZ - TOPUP"
  global.ownerName = "TAMZHOST"
  
  
  global.linktt = "https://www.tiktok.com/@"
  global.linkig = "https://www.instagram.com/"
  global.dana = "085xxxxxx"
  global.sawer = "Scan qris di atas"
  global.linkgc1 = "https://"
  global.linkgc2 = "https://chat.whatsapp.com/"
  
  global.packname = "Sticker By"
  global.author = "tamz"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})

module.exports = { payment, apikeyAtlantic }