let currentPlayer = 'X';
let board = Array(9).fill(null);
let moves = { 'X': [], 'O': [] };

document.querySelectorAll('.cell').forEach(cell => {
  cell.addEventListener('click', handleCellClick);
});

document.getElementById('reset-button').addEventListener('click', resetGame);

function handleCellClick(event) {
  const cell = event.target;
  const cellIndex = Array.from(cell.parentNode.children).indexOf(cell);

  if (board[cellIndex] !== null) {
    return; // Cell is already occupied
  }

  board[cellIndex] = currentPlayer;
  cell.textContent = currentPlayer;

  moves[currentPlayer].push(cellIndex);
  if (moves[currentPlayer].length > 3) {
    const removedIndex = moves[currentPlayer].shift();
    board[removedIndex] = null;
    document.getElementById(`cell${removedIndex}`).textContent = '';
  }

  if (checkWin(currentPlayer)) {
    setTimeout(() => {
      alert(`${currentPlayer} wins!`);
      resetGame();
    }, 100);
  } else {
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
  }
}

function checkWin(player) {
  const winPatterns = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
        [0, 4, 8], [2, 4, 6] // diagonals
    ];

  return winPatterns.some(pattern =>
    pattern.every(index => board[index] === player)
  );
}

function resetGame() {
  board.fill(null);
  moves = { 'X': [], 'O': [] };
  currentPlayer = 'X';
  document.querySelectorAll('.cell').forEach(cell => {
    cell.textContent = '';
  });
}