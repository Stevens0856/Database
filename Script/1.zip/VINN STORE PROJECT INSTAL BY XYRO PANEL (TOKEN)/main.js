require("./all/global")
const func = require("./all/place")
const readline = require("readline")
const welcome = JSON.parse(fs.readFileSync("./all/database/welcome.json"))
const NodeCache = require("node-cache")
const msgRetryCounterCache = new NodeCache()
const yargs = require('yargs/yargs')
const _ = require('lodash')
const usePairingCode = true
const question = (text) => {
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
})
return new Promise((resolve) => {
rl.question(text, resolve)
})}

async function startSesi() {
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
const { state, saveCreds } = await useMultiFileAuthState(`./session`)
const { version, isLatest } = await fetchLatestBaileysVersion()

const connectionOptions = {
version,
printQRInTerminal: !usePairingCode,
logger: pino({ level: "silent" }),
auth: state,
browser: ["Android","Safari","20.0.04"],
getMessage: async (key) => {
if (store) {
const msg = await store.loadMessage(key.remoteJid, key.id, undefined)
return msg?.message || undefined
}
return {
conversation: 'WhatsApp Bot By Xyro'
}}
}

const Xyro = func.makeWASocket(connectionOptions)
if (usePairingCode && !Xyro.authState.creds.registered) {
var phoneNumber = await question(chalk.black(chalk.bgGreen(`Please type your WhatsApp number :\n`)))
phoneNumber = phoneNumber.replace(/[^0-9]/g, '')
var code = await Xyro.requestPairingCode(phoneNumber.trim())
code = code?.match(/.{1,4}/g)?.join("-") || code
console.log(chalk.black(chalk.bgGreen(`Your Pairing Code : `)), chalk.black(chalk.bgWhite(code)))
}

Xyro.ev.on('creds.update', await saveCreds)
store?.bind(Xyro.ev)

Xyro.ev.on('call', async (user) => {
if (!global.anticall) return
let botNumber = await Xyro.decodeJid(Xyro.user.id)
for (let ff of user) {
if (ff.isGroup == false) {
if (ff.status == "offer") {
let sendcall = await Xyro.sendMessage(ff.from, {text: `@${ff.from.split("@")[0]} Maaf Kamu Akan Saya Block Karna Ownerbot Menyalakan Fitur *Anticall*\nJika Tidak Sengaja Segera Hubungi Owner Untuk Membuka Blokiran Ini`, contextInfo: {mentionedJid: [ff.from], externalAdReply: {thumbnailUrl: global.imgreply, title: "乂 Panggilan Terdeteksi", body: "Powered By "+global.namabot, previewType: "PHOTO"}}}, {quoted: null})
Xyro.sendContact(ff.from, [owner], "Telfon Atau Vc = Block", sendcall)
await sleep(7000)
await Xyro.updateBlockStatus(ff.from, "block")
}}
}})

Xyro.public = true

Xyro.ev.on('messages.upsert', async (chatUpdate) => {
try {
m = chatUpdate.messages[0]
if (!m.message) return
m.message = (Object.keys(m.message)[0] === 'ephemeralMessage') ? m.message.ephemeralMessage.message : m.message
if (m.key && m.key.remoteJid === 'status@broadcast') {
if (global.autoreadsw) Xyro.readMessages([m.key])
}
if (!Xyro.public && m.key.remoteJid !== global.owner+"@s.whatsapp.net" && !m.key.fromMe && chatUpdate.type === 'notify') return
if (m.isBaileys) return
if (global.autoread) Xyro.readMessages([m.key])
m = func.smsg(Xyro, m, store)
require("./Xyro.js")(Xyro, m, store)
} catch (err) {
console.log(err)
}
})

Xyro.ev.on('group-participants.update', async (anu) => {
if (!welcome.includes(anu.id)) return
let botNumber = await Xyro.decodeJid(Xyro.user.id)
if (anu.participants.includes(botNumber)) return
try {
let metadata = await Xyro.groupMetadata(anu.id)
let namagc = metadata.subject
let participants = anu.participants
for (let num of participants) {
let check = anu.author !== num && anu.author.length > 1
let tag = check ? [anu.author, num] : [num]
try {
ppuser = await Xyro.profilePictureUrl(num, 'image')
} catch {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}
if (anu.action == 'add') {
Xyro.sendMessage(anu.id, {text: check ? `@${anu.author.split("@")[0]} Telah Menambahkan @${num.split("@")[0]} Ke Dalam Grup Ini

*🏠 Grup Komunitas Bot Vinn Store :* https://chat.whatsapp.com/J3VSC8b7AZQLDJwjToqUwL

*🏠 Grup Komunitas Bot Vinn Store :* https://chat.whatsapp.com/J3VSC8b7AZQLDJwjToqUwL

*🏠 Saluran Testimoni Vinn Store :* https://whatsapp.com/channel/0029VadiD8q9WtBuMNO3R72I

*🏠 Ch Testimoni Vinn :* https://whatsapp.com/channel/0029VadiD8q9WtBuMNO3R72I` : `Hallo Kak @${num.split("@")[0]} Selamat Datang Di *${namagc}*

*🏠 Ch Testimoni Vinn :* https://whatsapp.com/channel/0029VadiD8q9WtBuMNO3R72I

*🏠 Ch Testimoni Vinn ) :* https://whatsapp.com/channel/0029VadiD8q9WtBuMNO3R72I

*🏠 Ch Xyro - Friends :* https://whatsapp.com/channel/0029VadiD8q9WtBuMNO3R72I

*🏠 Ch Testimoni Xyro :* https://whatsapp.com/channel/0029VaeZzWCJpe8ZiMEj7s2o`, 
contextInfo: {mentionedJid: [...tag], externalAdReply: { thumbnailUrl: ppuser, title: '© Welcome Message', body: '', renderLargerThumbnail: true, sourceUrl: "https://whatsapp.com/channel/0029VadiD8q9WtBuMNO3R72I", mediaType: 1}}})
} 
if (anu.action == 'remove') { 
Xyro.sendMessage(anu.id, {text: check ? `@${anu.author.split("@")[0]} Telah Mengeluarkan @${num.split("@")[0]} Dari Grup Ini

*🏠 Grup Komunitas Bot Vinn Store :* https://chat.whatsapp.com/J3VSC8b7AZQLDJwjToqUwL

*🏠 Grup Komunitas Bot Vinn Store :* https://chat.whatsapp.com/J3VSC8b7AZQLDJwjToqUwL

*🏠 Saluran Testimoni Vinn Store :* https://whatsapp.com/channel/0029VadiD8q9WtBuMNO3R72I

*🏠 Saluran Testimoni Vinn Store :* https://whatsapp.com/channel/0029VaeZzWCJpe8ZiMEj7s2o` : `@${num.split("@")[0]} Telah Keluar Dari Grup Ini

*🏠 Grup Komunitas Bot Vinn Store :* https://chat.whatsapp.com/J3VSC8b7AZQLDJwjToqUwL

*🏠 Grup Komunitas Bot Vinn Store :* https://chat.whatsapp.com/J3VSC8b7AZQLDJwjToqUwL

*🏠 Saluran Testimoni Vinn Store :* https://whatsapp.com/channel/0029VadiD8q9WtBuMNO3R72I

*🏠 Ch Testimoni Xyro :* https://whatsapp.com/channel/0029VadiD8q9WtBuMNO3R72I`, 
contextInfo: {mentionedJid: [...tag], externalAdReply: { thumbnailUrl: ppuser, title: '© Leaving Message', body: '', renderLargerThumbnail: true, sourceUrl: "https://whatsapp.com/channel/0029Vae687D72WTr2uAMrX2k", mediaType: 1}}})
}
if (anu.action == "promote") {
Xyro.sendMessage(anu.id, {text: `@${anu.author.split("@")[0]} Telah Menjadikan @${num.split("@")[0]} Sebagai Admin Grup Ini

*🏠 Grup Komunitas Bot Vinn Store :* https://chat.whatsapp.com/J3VSC8b7AZQLDJwjToqUwL

*🏠 Grup Komunitas Bot Vinn Store :* https://chat.whatsapp.com/J3VSC8b7AZQLDJwjToqUwL

*🏠 Saluran Testimoni Vinn Store :* https://whatsapp.com/channel/0029VadiD8q9WtBuMNO3R72I

*🏠 Ch Testimoni vinn :* https://whatsapp.com/channel/0029VadiD8q9WtBuMNO3R72I`, 
contextInfo: {mentionedJid: [...tag], externalAdReply: { thumbnailUrl: ppuser, title: '© Promote Message', body: '', renderLargerThumbnail: true, sourceUrl: "https://whatsapp.com/channel/0029Vae687D72WTr2uAMrX2k", mediaType: 1}}})
}
if (anu.action == "demote") {
Xyro.sendMessage(anu.id, {text: `@${anu.author.split("@")[0]} Telah Memberhentikan @${num.split("@")[0]} Sebagai Admin Grup Ini

*🏠 Grup Komunitas Bot Vinn Store :* https://chat.whatsapp.com/J3VSC8b7AZQLDJwjToqUwL

*🏠 Grup Komunitas Bot Vinn Store :* https://chat.whatsapp.com/J3VSC8b7AZQLDJwjToqUwL

*🏠 Saluran Testimoni Vinn Store :* https://whatsapp.com/channel/0029VadiD8q9WtBuMNO3R72I

*🏠 Ch Testimoni Vinn  :* https://whatsapp.com/channel/0029VadiD8q9WtBuMNO3R72I`, 
contextInfo: {mentionedJid: [...tag], externalAdReply: { thumbnailUrl: ppuser, title: '© Demote Message', body: '', renderLargerThumbnail: true, sourceUrl: "https://whatsapp.com/channel/0029Vae687D72WTr2uAMrX2k", mediaType: 1}}})
}
} 
} catch (err) {
console.log(err)
}})

Xyro.ev.on('connection.update', async (update) => {
const { connection, lastDisconnect } = update
if (connection === 'close') {
const reason = new Boom(lastDisconnect?.error)?.output.statusCode
console.log(color(lastDisconnect.error, 'deeppink'))
if (lastDisconnect.error == 'Error: Stream Errored (unknown)') {
process.exit()
} else if (reason === DisconnectReason.badSession) {
console.log(color(`Bad Session File, Please Delete Session and Scan Again`))
process.exit()
} else if (reason === DisconnectReason.connectionClosed) {
console.log(color('[SYSTEM]', 'white'), color('Connection closed, reconnecting...', 'deeppink'))
process.exit()
} else if (reason === DisconnectReason.connectionLost) {
console.log(color('[SYSTEM]', 'white'), color('Connection lost, trying to reconnect', 'deeppink'))
process.exit()
} else if (reason === DisconnectReason.connectionReplaced) {
console.log(color('Connection Replaced, Another New Session Opened, Please Close Current Session First'))
Xyro.logout()
} else if (reason === DisconnectReason.loggedOut) {
console.log(color(`Device Logged Out, Please Scan Again And Run.`))
Xyro.logout()
} else if (reason === DisconnectReason.restartRequired) {
console.log(color('Restart Required, Restarting...'))
await startSesi()
} else if (reason === DisconnectReason.timedOut) {
console.log(color('Connection TimedOut, Reconnecting...'))
startSesi()
}
} else if (connection === "connecting") {
console.log(color('Menghubungkan . . . '))
} else if (connection === "open") {
let teksnotif = `*Revv Bot - Bot*
Connected To ${Xyro.user.id.split(":")[0]}`
Xyro.sendMessage("6289654096234@s.whatsapp.net", {text: teksnotif})
console.log(color('Bot Berhasil Tersambung'))
}
})

return Xyro
}

startSesi()

process.on('uncaughtException', function (err) {
console.log('Caught exception: ', err)
})