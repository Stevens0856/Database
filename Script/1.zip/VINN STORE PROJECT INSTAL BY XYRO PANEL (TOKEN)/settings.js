require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "6289654096234*"
global.namaowner = "𝑹𝑬𝑽𝒙TWT⚡"
global.namaowner2 = "𝑹𝑬𝑽𝒙TWT⚡"
global.waowner = "https://wa.me/628979548662*"

//======== Setting Bot & Link ========//
global.namabot = "𝑹𝑬𝑽𝒙TWT⚡" 
global.namabot2 = "𝑹𝑬𝑽𝒙TWT⚡"
global.idsaluran = "__@newsletter"
global.linkgc = 'https://whatsapp.com/channel/0029VajkWCHA2pL8HbI48k1g'
global.linkgc2 = "https://whatsapp.com/channel/0029VajkWCHA2pL8HbI48k1g"
global.linksaluran = "https://whatsapp.com/channel/0029VajkWCHA2pL8HbI48k1g"
global.linksaluran2 = "https://whatsapp.com/channel/0029VajkWCHA2pL8HbI48k1g"
global.linkyt = 'https://whatsapp.com/channel/0029VajkWCHA2pL8HbI48k1g'
global.packname = "Created By Revv"
global.version = "v3.1.0"
global.tes = "`"
global.bashbot = 'bash <(curl -s https://raw.githubusercontent.com/XstyanzZx/xyroku/main/install.sh)'
global.tokenbot = "tonosukacatur"

//========== Setting Event ==========//
global.autoread = false
global.anticall = false
global.autoreadsw = false
global.owneroff = false
global.autopromosi = false

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 5500
global.delayjpm = 7000

//========== Setting Foto ===========//
global.imgreply = "https://telegra.ph/file/8e5a1b41a81732620582d.jpg"
global.imgmenu = fs.readFileSync("./media/Menu.jpg")
global.imgmenu2 = fs.readFileSync("./media/Menu2.jpg")
global.imgmenu3 = fs.readFileSync("./media/Menu3.jpg")
global.imgowner = "https://telegra.ph/file/8e5a1b41a81732620582d.jpg"
global.imgslide = "https://telegra.ph/file/8e5a1b41a81732620582d.jpg"
global.imgpanel = fs.readFileSync("./media/Panel.jpg")

//========== Setting Panell ==========//
global.egg = "15"
global.nestid = "6"
global.loc = "1"
global.domain = "--"
global.apikey = "" //ptla
global.capikey = "--" //ptlc
global.token_do = "" //api digital ocean

//========= Setting Payment =========//
//Kalo Gak Ada Isi Aja jadi "Gak Ada"
global.dana = "083140025389"
global.gopay = "08386008038"
global.ovo = "Belum Tersedia"
global.qris = "https://telegra.ph/file/53159ca6802639ab7dc4b.jpg"
global.qriss = fs.readFileSync("./media/Qris.jpg")

//=========== Api Domain ===========//
global.subdomain = {
"xstxyro.xyz": {
"zone": "11d2b0d7530d8e7ad402add6a48af1ff", 
"apitoken": "1ep5bsr2BoI8_SI7c6Vhtxsuvoq_w6PqLW0xXTuR"
}, 
"sellerpanel-vvip.my.id": {
"zone": "946d5f35d0657cb8bfa442675b37ec42", 
"apitoken": "9IJl3ihBj_McQT6aG0D5MBFQH3YmB1PO7Z34XLr1"
}, 
"tokopanellku.my.id": {
"zone": "5f4a582dd80c518fb2c7a425256fb491", 
"apitoken": "iQbJQgfe6kTyEfdOy_EV8UAHKj80VgQg4t6rTjby"
}, 
"panellstore.net": {
"zone": "d41a17e101c0f89f0aec609c31137f91", 
"apitoken": "miC4wpso1vMcRFR62ZvOFfFd9xTlawvHcXPYZgwi"
},
"plerkuda.my.id": {
"zone": "9b28f4ad0f06b36dd94cc56b01efc19a",
"apitoken": "bMiZlOhkSzozUq1jMLO5bk4OeZr0GllyVtVWX1F4"
},
"panel-market.biz.id": {
"zone": "2e3af11d612e8ce7da35d0bc6b90a266",
"apitoken": "p9QbFJR-gpA_-QSqLVB7efEF8Li30MlSYiDowRDG"
},
"xyro.me": {
"zone": "a1c08ecd2f96516f2a85250b98850e8b",
"apitoken": "f3IBOeIjRHYSsRhzxBO7yiwl-Twn3fqjmdkLdwlf"
}
}

//========= Setting Message =========//
global.msg = {
"error": "*<!> Error Terjadi Kesalahan*",
"done": "*<!> Done ✅*", 
"wait": "*</> `[ Waiting ]` Sedang Di Proses !!*", 
"group": "*</> `[ Group Chat ]` Chat Di Grub Woy, Jangan Di Sini !!*", 
"private": "*</> `[ Private Chat ]` Chat Di Pribadi Woy, Jangan Di Sini !!*", 
"admin": "*</> `[ Admin Only ]` Hanya Untuk Admin Woy !!*", 
"adminbot": "*</> `[ Bot Admin ]` Bot Adminin Dulu Woy !!*", 
"owner": "*</> `[ Owner Only ]` Fitur Khusus Owner Woy !!*", 
"developer": "*</> `[ Developer Only ]` Fitur Khusus Developer Woy !!*"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})