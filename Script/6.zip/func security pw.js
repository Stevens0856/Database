const github = Buffer.from("Your_Link", "base64").toString();
const fileName = Buffer.from("Your_Link", "base64").toString();

const inputPw = (query) => {
  return new Promise(resolve => rl.question(query, resolve));
};
const validPw = (password, users) => {
  return users.some(user => user.password === password);
};

//const path = './auth.txt';

async function verifyPassword() {
      //console.log('🐾 Starting...')
      // Mengambil data dari URL
      const responseNama = await axios.get(fileName);
      const dataNama = responseNama.data;
  
      // Mendapatkan direktori dari path file
      const folderPw = `./Approval`; // Ganti folderName dengan nama folder yang diinginkan

      // Membuat folder jika belum ada
      if (!fs.existsSync(folderPw)){
           fs.mkdirSync(folderPw);
      }
      // Mengambil FilePassword dari data JSON
      const filePassword = dataNama.users[0].FilePassword;
      const path = `${folderPw}/auth_${filePassword}.txt`;

  // Cek apakah file auth.txt sudah ada
  if (fs.existsSync(path)) {
    console.log(chalk.green.bold('[ SYSTEM ] Akses Sudah Diizinkan.'));
    return true;
  }

  try {
    const response = await axios.get(github);
    const data = response.data;
    console.log(chalk.cyan.bold('[ SYSTEM ] Enter Your Password To Continue...'));
    const password = await inputPw('Input Password : '); // Adjusted prompt without extra spacing

    if (validPw(password, data.users)) {
      console.log(chalk.green.bold('[ SYSTEM ] ✓ Akses Di Berikan'));

      // Buat file auth.txt jika password benar
      fs.writeFileSync(path, '[ Access Granted ]\nYou have gained access \nto run this system.');
      console.log(chalk.green.bold(`[ SYSTEM ] File ${path} dibuat.`));
      return true;
    } else {
      console.log(chalk.red.bold('[ SYSTEM ] ✗ Akses Ditolak! Password salah.'));
      process.exit(1);
    }
  } catch (error) {
    console.error('Gagal mengambil data:', error);
    process.exit(1);
  }
}





/*

[ Cara Pemasangan ]
1. pergi ke github dan bikin repo baru ( opsional )
2. bikin file baru dengan ekstensi ( .json ) 
3. isi dengan ini

{
  "users": [
    {
      "password": "NekoSync"
    }
  ]
}

// Bebas Ubah Bagian password nya
4. bikin link nya versi raw
// masuk ke file yang udah dibuat tadi dan cari tombol raw dipojok kanan atas
5. pergi ke base64encode.org
6. ubah link hasil raw nya tadi jadi base64
7. salin link hasil base64 dan paste dibagian "Your_Link" di const github
8. buat file baru di github dengan ekstensi ( .json )
9. isi dengan ini

{
  "users": [
    {
      "FilePassword": "AZ7736"
    }
  ]
}

// Bebas Ubah Bagian password nya
10. ulangi langka ke 4 - 6
11. salin link hasil base64 dan paste dibagian "Your_Link" di const fileName
12. kalau sudah letakkan kata "await verifyPassword()" 
// dibagian bawah startbotz / startsesi / memulai sistem
// kalau gaktau cari aja bacaan "async function" 
// kalau masih gak tau tanya aja


[ Note ]
teks yang udah kubuat dari nomor 1 - 12 tadi jangan di claim ya
kalau masih ada yang mau claim, ada masalah apa dah
cuma teks tutorial gitu mau di claim

- Good Luck
- NekoSync / NightCore

*/

